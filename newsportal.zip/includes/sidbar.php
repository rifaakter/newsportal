<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>sidebar</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" />



    <style>
        .sidebar {
            display: grid;
            height: 30vh;


        }

        .icon-list {}

        .icon-list ul {}

        .icon-list ul li {}

        .icon-list ul li a {}
    </style>
</head>

<body>
    <div class="sidebar">
        <ul class="icon-list">
            <li><i class="fa-solid fa-gauge"></i><a href="#">Deshbord</a> </li>
            <li><i class="fa-solid fa-upload"></i><a href="#">Upload</a> </li>
            <li><i class="fa-solid fa-pen"></i></i><a href="#">Upload</a></li>
            <li><i class="fa-solid fa-eye"></i></i> <a href="#">View</a></li>
            <li><i class="fa-solid fa-blog"></i></i> <a href="#">Bloge</a></li>
            <li><i class="fa-solid fa-phone"></i></i> <a href="#">Contact</a></li>
            <li><i class="fa-solid fa-user"></i></i> <a href="#">About</a></li>
            <li><i class="fa-solid fa-gears"></i></i> <a href="#">Settings</a></li>
        </ul>
    </div>
</body>

</html>