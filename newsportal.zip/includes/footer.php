<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>footer</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<footer>
  
    <div class="footer-content">
      <h3>Footer section</h3>
      <ul>
        <li><a href="#">Home</a></li>
        <li><a href="#">About</a></li>
        <li><a href="#">Contact</a></li>
      </ul>
      
    </div>
    <p>&copy; 2024 Your Website</p>
  </footer>
</body>
</html>