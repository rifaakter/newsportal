<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>content page</title>
    <link rel="stylesheet" href="../assets/style.css">
    <link rel="stylesheet" href="../assets/content.css">
</head>

<body>

    <marquee behavior="scroll" direction="left" class="marquee">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ipsa aliquid nisi saepe facilis, suscipit beatae! . Lorem ipsum dolor sit, amet consectetur adipisicing elit. Incidunt natus est, accusantium quia perspiciatis cupiditate consequuntur ab aliquid. Similique libero fugiat nam beatae amet laborum impedit fugit, consectetur nemo consequatur.</marquee>

    <div class="content-box con-aria">

        <div class="carousel-container">

                <img src="https://marketplace.canva.com/EAFd5YBOSqM/1/0/1600w/canva-yellow-and-black-news-youtube-thumbnail-yx6L2nJMKjE.jpg" alt="Image 2">
                
                <!-- Add more slides as needed -->
            
        </div>
        <div class="content-list">
            <div class="news">
                <h3>News title </h3>
                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sed voluptas modi vero tempora animi adipisci nostrum possimus nisi maiores fuga?</p>
                <a href="#">More</a>
            </div> <br>
            <div class="news">
                <h3>News title 1</h3>
                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sed voluptas modi vero tempora animi adipisci nostrum possimus nisi maiores fuga?</p>
                <a href="#">More</a>
            </div>
        </div>
    </div>

    <div class="content-box con-aria">

        <div class="carousel-container">

                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS7l-DhWdraiv3euef8GsOoTyQYAFiHNGnRal11U66WEg&s" alt="Image 1">
                
                <!-- Add more slides as needed -->
            
        </div>
        <div class="content-list">
            <div class="news">
                <h3>News title </h3>
                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sed voluptas modi vero tempora animi adipisci nostrum possimus nisi maiores fuga?</p>
                <a href="#">More</a>
            </div> <br>
            <div class="news">
                <h3>News title 1</h3>
                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sed voluptas modi vero tempora animi adipisci nostrum possimus nisi maiores fuga?</p>
                <a href="#">More</a>
            </div>
        </div>
    </div>
</body>

</html>