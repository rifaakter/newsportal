<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>nab menu</title>
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" > -->
    <link rel="stylesheet" href="../assets/style.css">

</head>

<body>

    <nav class="nav-menu">
        <div class="container">
            <div class="company--logo">
                <a href="#"> It way bd news</a>
            </div>
            <div class="menu--list">
                <ul>
                    <li> <a href="./includes/content_view.php">Home</a></li>
                    <li><a href="#"> contact</a></li>
                    <li><a href="#"> bloge</a></li>
                    <li><a href="#"> about</a></li>
                    <li>
                        <a href="./includes/login.php">login</a>
                    </li>
                </ul>
            </div>
        </div>

    </nav>

    <!-- java script include cnd link -->
    <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" ></script> -->


    <script src="./assets/scripet.js"></script>
</body>

</html>